#ifndef _COREGAME_
#define _COREGAME_

#include "../grid/grid.h"
#include "texture/texture.h"
#include <SDL2/SDL.h>
#include <glad/glad.h>
#include <iostream>
#include <memory>
#include <string>
#include <unit/unit.h>
#include <unordered_map>
#include <vector>

using namespace std;

class Game {
  public:
	Game();
	~Game();

	bool init(int mapH, int mapW,
			  int num); // Third value is the number of units to create
	void createGrid();
	void runLoop();
	void handleEvents();
	void update();
	void render();
	void clean();

	void loadTexture(const std::string &name, const char *path);
	Texture *getTexture(const std::string &name);

	void loadShader(const std::string &name, const char *path);
	std::string *getShader(const std::string &name);

  private:
	SDL_Window *window;
	SDL_GLContext context;
	bool isRunning;

	std::unordered_map<std::string, std::unique_ptr<Texture>> textureMap;
	std::unordered_map<std::string, std::unique_ptr<std::string>> ShaderMap;
	std::unique_ptr<Grid> grid;
	std::vector<std::unique_ptr<Unit>> unit;
	std::vector<vector<unsigned int>> occupancyGrid;
};

#endif
